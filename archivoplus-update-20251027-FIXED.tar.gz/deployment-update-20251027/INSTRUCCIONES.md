# 📦 Instrucciones de Actualización - ArchivoPlus
**Fecha:** 27 de Octubre 2025
**Versión:** v3.1.1

## 📋 Cambios Incluidos

### Frontend:
- ✅ Nuevo icono `audifono.png` para módulos de audio
- ✅ **CRÍTICO:** `axios.js` actualizado con exportación `getApiUrl`
- ✅ Mejoras en `ComercialesManager.jsx` (iconos de audio actualizados)
- ✅ Mejoras en `SystemInfoManager.jsx` (edición y borrado de versiones)
- ✅ Actualizaciones en componentes de audio y edición

### Backend:
- ✅ Mejoras en `settings.py` (configuración de entorno)
- ✅ Actualizaciones en `views.py` y `csv_views.py`

---

## 🚀 Pasos para Actualizar Producción

### 1️⃣ **Respaldar Archivos Actuales (IMPORTANTE)**

```bash
# En el servidor de producción, crear backup
cd /ruta/a/archivoplus
tar -czf backup-$(date +%Y%m%d-%H%M%S).tar.gz \
  frontend/public/icons/audifono.png \
  frontend/src/components/ComercialesManager.jsx \
  frontend/src/components/SystemInfoManager.jsx \
  frontend/src/components/ComercialEditModal.jsx \
  frontend/src/components/AudioWavePlayer.jsx \
  frontend/src/components/AudioEncodingModal.jsx \
  frontend/src/components/RepositoriosManager.jsx \
  archivoplus_backend/settings.py \
  core/views.py \
  core/csv_views.py
```

### 2️⃣ **Subir Archivos al Servidor**

```bash
# Desde tu máquina local, subir el paquete al servidor
scp -r deployment-update-20251027 usuario@servidor:/tmp/
```

### 3️⃣ **Copiar Archivos en el Servidor**

```bash
# En el servidor de producción
cd /ruta/a/archivoplus

# CRÍTICO: Copiar axios.js actualizado (PRIMERO)
cp /tmp/deployment-update-20251027/frontend/src/utils/axios.js frontend/src/utils/

# Copiar icono (debe estar antes del build)
cp /tmp/deployment-update-20251027/frontend/public/icons/audifono.png frontend/public/icons/

# Copiar componentes del frontend
cp /tmp/deployment-update-20251027/frontend/src/components/*.jsx frontend/src/components/

# Copiar archivos del backend
cp /tmp/deployment-update-20251027/archivoplus_backend/settings.py archivoplus_backend/
cp /tmp/deployment-update-20251027/core/views.py core/
cp /tmp/deployment-update-20251027/core/csv_views.py core/
```

### 4️⃣ **Rebuild del Frontend**

```bash
cd frontend

# Limpiar cache y node_modules si es necesario
rm -rf node_modules/.vite
rm -rf dist

# Rebuild
npm run build
```

### 5️⃣ **Reiniciar Servicios Backend**

```bash
# Si usas PM2
pm2 restart archivoplus-backend
pm2 restart archivoplus-celery

# O si usas systemd
sudo systemctl restart archivoplus-backend
sudo systemctl restart archivoplus-celery

# O si usas Docker
docker-compose restart backend celery
```

### 6️⃣ **Reiniciar Nginx (Si es necesario)**

```bash
# macOS
brew services restart nginx

# Linux
sudo systemctl restart nginx
```

### 7️⃣ **Verificar la Actualización**

```bash
# Verificar que el icono nuevo esté disponible
curl -I http://tu-servidor/icons/audifono.png

# Debe retornar: HTTP/1.1 200 OK

# Verificar que el frontend cargue correctamente
curl http://tu-servidor/

# Verificar que el backend responda
curl http://tu-servidor/api/health/
```

### 8️⃣ **Limpiar Cache del Navegador**

En tu navegador:
- **Mac**: `Cmd + Shift + R`
- **Windows/Linux**: `Ctrl + Shift + R`

O:
1. Abrir DevTools (F12)
2. Click derecho en el botón de refresh
3. "Empty Cache and Hard Reload"

---

## ⚠️ Notas Importantes

1. **axios.js**: **CRÍTICO** - Este archivo DEBE actualizarse PRIMERO porque `ComercialesManager.jsx` depende de la función `getApiUrl` que antes no existía.

2. **Icono audifono.png**: Debe estar en `frontend/public/icons/` ANTES de hacer el build.

3. **Cache Busting**: Los archivos usan `?v=20251027-final` para evitar problemas de caché.

4. **Permisos**: Asegúrate de que los archivos tengan los permisos correctos:
   ```bash
   chmod 644 frontend/src/utils/axios.js
   chmod 644 frontend/public/icons/audifono.png
   chmod 644 frontend/src/components/*.jsx
   chmod 644 archivoplus_backend/settings.py
   chmod 644 core/*.py
   ```

5. **Variables de Entorno**: Verifica que el archivo `.env` en producción tenga las configuraciones correctas.

---

## 🔍 Verificación Post-Actualización

### Checklist:
- [ ] Icono `audifono.png` visible en módulos de audio
- [ ] System Information manager permite editar y borrar versiones
- [ ] Frontend carga sin errores en la consola del navegador
- [ ] Backend responde correctamente a las peticiones API
- [ ] Exportación CSV funciona correctamente
- [ ] No hay errores en los logs del servidor

### Ver Logs:
```bash
# PM2
pm2 logs archivoplus-backend --lines 50

# Django logs
tail -f /ruta/a/archivoplus/logs/django.log

# Nginx logs
tail -f /opt/homebrew/var/log/nginx/error.log
```

---

## 🆘 Rollback en Caso de Problemas

```bash
# Restaurar desde el backup
cd /ruta/a/archivoplus
tar -xzf backup-YYYYMMDD-HHMMSS.tar.gz

# Rebuild frontend
cd frontend
npm run build

# Reiniciar servicios
pm2 restart all
```

---

## 📞 Soporte

Si encuentras algún problema durante la actualización:
1. Revisa los logs del servidor
2. Verifica que todos los archivos se copiaron correctamente
3. Asegúrate de que el build del frontend se completó sin errores
4. Limpia completamente la caché del navegador

---

**¡Listo para actualizar!** 🚀
