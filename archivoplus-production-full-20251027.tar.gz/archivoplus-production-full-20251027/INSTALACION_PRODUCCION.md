# 🚀 Instalación Completa en Producción - ArchivoPlus
**Versión:** v3.1.2
**Fecha:** 27 de Octubre 2025
**Servidor:** Sin Docker (Instalación Nativa)

---

## 📋 Pre-requisitos del Servidor

### Sistema Operativo
- macOS (Mac M4 recomendado) o Linux
- Acceso root o sudo

### Software Requerido

#### 1. Python 3.11+
```bash
# macOS
brew install python@3.11

# Linux
sudo apt update
sudo apt install python3.11 python3.11-venv python3-pip
```

#### 2. Node.js 20+
```bash
# macOS
brew install node@20

# Linux
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

#### 3. PostgreSQL 15+
```bash
# macOS
brew install postgresql@15
brew services start postgresql@15

# Linux
sudo apt install postgresql-15 postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

#### 4. Redis
```bash
# macOS
brew install redis
brew services start redis

# Linux
sudo apt install redis-server
sudo systemctl start redis
sudo systemctl enable redis
```

#### 5. FFmpeg
```bash
# macOS
brew install ffmpeg

# Linux
sudo apt install ffmpeg
```

#### 6. Nginx
```bash
# macOS
brew install nginx
brew services start nginx

# Linux
sudo apt install nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

---

## 📦 Paso 1: Subir Archivos al Servidor

```bash
# Desde tu máquina local
scp archivoplus-production-full-20251027.tar.gz usuario@servidor:/tmp/

# Conectar al servidor
ssh usuario@servidor

# Extraer en el directorio deseado
cd /var/www  # o ~/Sites o la ruta que prefieras
sudo tar -xzf /tmp/archivoplus-production-full-20251027.tar.gz
sudo mv archivoplus-production-full-20251027 archivoplus
cd archivoplus
```

---

## 🗄️ Paso 2: Configurar Base de Datos

```bash
# Crear usuario y base de datos PostgreSQL
sudo -u postgres psql

# En el prompt de PostgreSQL:
CREATE USER archivoplus_user WITH PASSWORD 'tu_password_seguro_aqui';
CREATE DATABASE archivoplus_prod OWNER archivoplus_user;
GRANT ALL PRIVILEGES ON DATABASE archivoplus_prod TO archivoplus_user;
\q
```

---

## ⚙️ Paso 3: Configurar Variables de Entorno

```bash
# Crear archivo .env en el directorio raíz
cd /var/www/archivoplus
nano .env
```

**Contenido del archivo `.env`:**

```bash
# Django Settings
DJANGO_SECRET_KEY=genera_una_clave_secreta_de_50_caracteres_minimo
DEBUG=False
ALLOWED_HOSTS=tu-dominio.com,tu-ip-servidor,localhost,127.0.0.1

# Database (PostgreSQL)
DATABASE_URL=postgresql://archivoplus_user:tu_password_seguro_aqui@localhost:5432/archivoplus_prod
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_USER=archivoplus_user
POSTGRES_PASSWORD=tu_password_seguro_aqui
POSTGRES_DB=archivoplus_prod

# Redis
REDIS_URL=redis://localhost:6379/0
REDIS_HOST=localhost
REDIS_PORT=6379

# CORS (Frontend)
CORS_ALLOWED_ORIGINS=http://tu-dominio.com,http://tu-ip-servidor

# FFmpeg Optimization
FFMPEG_THREADS=8
FFMPEG_PRESET=fast
FFMPEG_HWACCEL=videotoolbox  # Para Mac, quitar en Linux

# Paths
MEDIA_ROOT=/var/www/archivoplus/media
STATIC_ROOT=/var/www/archivoplus/static

# Email (opcional)
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=tu-email@gmail.com
EMAIL_HOST_PASSWORD=tu-app-password
```

---

## 🐍 Paso 4: Configurar Backend (Django)

```bash
cd /var/www/archivoplus

# Crear entorno virtual
python3.11 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install --upgrade pip
pip install -r requirements.txt

# Crear directorios para media
mkdir -p media/originals media/transcoded media/thumbnails
mkdir -p static

# Ejecutar migraciones
python manage.py migrate

# Crear superusuario
python manage.py createsuperuser
# Usuario: admin
# Email: admin@tudominio.com
# Password: (elige uno seguro)

# Recolectar archivos estáticos
python manage.py collectstatic --noinput

# Ajustar permisos
sudo chown -R www-data:www-data media static  # Linux
# o
sudo chown -R $(whoami):staff media static     # macOS
```

---

## 🎨 Paso 5: Configurar Frontend (React)

```bash
cd /var/www/archivoplus/frontend

# Instalar dependencias
npm install

# Configurar variables de entorno del frontend
cat > .env.local << EOF
VITE_API_URL=http://tu-ip-servidor:8000
EOF

# Build para producción
npm run build

# El build estará en frontend/dist/
```

---

## 🌐 Paso 6: Configurar Nginx

```bash
# Crear configuración de Nginx
sudo nano /etc/nginx/sites-available/archivoplus
# o en macOS:
sudo nano /opt/homebrew/etc/nginx/servers/archivoplus.conf
```

**Contenido de la configuración Nginx:**

```nginx
server {
    listen 80;
    server_name tu-dominio.com tu-ip-servidor;

    client_max_body_size 2000M;
    
    # Frontend React
    location / {
        root /var/www/archivoplus/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    # API Django
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Admin Django
    location /admin/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Archivos multimedia
    location /media/ {
        alias /var/www/archivoplus/media/;
        expires 1y;
        add_header Cache-Control "public, immutable";
        
        # Streaming de video optimizado
        mp4;
        mp4_buffer_size 1m;
        mp4_max_buffer_size 5m;
    }

    # Archivos estáticos
    location /static/ {
        alias /var/www/archivoplus/static/;
        expires 1y;
        add_header Cache-Control "public";
    }
}
```

```bash
# Habilitar sitio (Linux)
sudo ln -s /etc/nginx/sites-available/archivoplus /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Reiniciar Nginx (macOS)
brew services restart nginx
```

---

## 🔄 Paso 7: Configurar Servicios con PM2

```bash
# Instalar PM2 globalmente
npm install -g pm2

# Crear archivo de configuración PM2
cd /var/www/archivoplus
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [
    {
      name: 'archivoplus-backend',
      script: 'venv/bin/python',
      args: 'manage.py runserver 127.0.0.1:8000',
      cwd: '/var/www/archivoplus',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '2G',
      env: {
        PYTHONUNBUFFERED: '1'
      }
    },
    {
      name: 'archivoplus-celery',
      script: 'venv/bin/python',
      args: '-m celery -A archivoplus_backend worker -l info --concurrency=8',
      cwd: '/var/www/archivoplus',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '4G'
    },
    {
      name: 'archivoplus-celery-beat',
      script: 'venv/bin/python',
      args: '-m celery -A archivoplus_backend beat -l info',
      cwd: '/var/www/archivoplus',
      instances: 1,
      autorestart: true,
      watch: false
    }
  ]
};
EOF

# Iniciar servicios
pm2 start ecosystem.config.js

# Ver estado
pm2 status

# Ver logs
pm2 logs

# Configurar auto-inicio
pm2 startup
pm2 save
```

---

## ✅ Paso 8: Verificación

```bash
# Verificar servicios
pm2 status

# Verificar Nginx
sudo nginx -t
curl http://localhost/

# Verificar API
curl http://localhost/api/health/

# Verificar PostgreSQL
psql -U archivoplus_user -d archivoplus_prod -c "SELECT 1;"

# Verificar Redis
redis-cli ping
```

---

## 🔐 Paso 9: Seguridad (Recomendado)

### Configurar Firewall
```bash
# Linux (UFW)
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 22/tcp
sudo ufw enable

# macOS
# Configurar desde Preferencias del Sistema > Seguridad > Firewall
```

### SSL/HTTPS (Opcional pero recomendado)
```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-nginx

# Obtener certificado
sudo certbot --nginx -d tu-dominio.com

# Renovación automática
sudo certbot renew --dry-run
```

---

## 🔄 Actualización del Sistema

Para actualizar en el futuro:

```bash
cd /var/www/archivoplus

# Pull de cambios
git pull origin main

# Activar entorno virtual
source venv/bin/activate

# Actualizar dependencias backend
pip install -r requirements.txt

# Migraciones
python manage.py migrate

# Recolectar estáticos
python manage.py collectstatic --noinput

# Rebuild frontend
cd frontend
npm install
npm run build

# Reiniciar servicios
cd ..
pm2 restart all
```

---

## 📊 Monitoreo

```bash
# Ver logs en tiempo real
pm2 logs

# Monitorear recursos
pm2 monit

# Ver estado de todos los servicios
pm2 status

# Logs de Nginx
tail -f /var/log/nginx/error.log
tail -f /var/log/nginx/access.log
```

---

## 🆘 Troubleshooting

### Backend no inicia
```bash
pm2 logs archivoplus-backend
# Revisar configuración en .env
# Verificar que PostgreSQL esté corriendo
```

### Frontend no carga
```bash
# Verificar que el build esté actualizado
cd frontend && npm run build
# Revisar logs de Nginx
tail -f /var/log/nginx/error.log
```

### Celery no procesa videos
```bash
pm2 logs archivoplus-celery
# Verificar que Redis esté corriendo
redis-cli ping
# Verificar que FFmpeg esté instalado
ffmpeg -version
```

---

## 📞 Acceso al Sistema

Una vez instalado:

- **Frontend**: http://tu-dominio.com o http://tu-ip-servidor
- **Admin**: http://tu-dominio.com/admin
- **API**: http://tu-dominio.com/api

**Usuario administrador:**
- Usuario: admin (o el que creaste)
- Password: (el que configuraste)

---

**¡Instalación completada!** 🎉

Para soporte adicional, revisa el README.md o los logs del sistema.
