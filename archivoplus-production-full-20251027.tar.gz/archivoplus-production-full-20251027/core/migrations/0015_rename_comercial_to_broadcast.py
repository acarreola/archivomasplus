# Generated manually
from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0014_comercial_encoded_files'),
    ]

    operations = [
        migrations.RenameModel(
            old_name='Comercial',
            new_name='Broadcast',
        ),
    ]
